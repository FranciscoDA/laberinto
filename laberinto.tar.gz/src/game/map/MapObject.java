package game.map;

/**
 * Clase vacia para agrupar a todos los objetos del mapa.
 * @author Francisco Altoe
 *
 */
public abstract class MapObject {

}
