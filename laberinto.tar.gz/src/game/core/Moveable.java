package game.core;

import state.GameState;

public interface Moveable {
	public void move (GameState gs);	
}
