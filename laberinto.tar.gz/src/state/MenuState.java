package state;

import game.core.GamePanel;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

public class MenuState extends State {

	@Override
	public void init(GamePanel gp) {
		//gp.add

	}

	@Override
	public void pause(GamePanel gp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume(GamePanel gp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void destroy(GamePanel gp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void logic(GamePanel gp) {
		// TODO Auto-generated method stub

	}

	@Override
	public void paint(GamePanel gp, Graphics2D g2d) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyPressed(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

}
